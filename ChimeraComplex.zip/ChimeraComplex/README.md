Chimera Complex

How to Play:

PC-------------------
Movement:   Arrow Keys
Shoot:      Left Ctrl
Open Door:  Space

Controller-----------
Movement:   Left Stick
Camera:     Right Stick
Shoot:      Right Bumper/R1
Open Door:  Left Bumper/L1

Lead/Graphics Programming/Controller Support by dhafo
Gameplay/AI Programming by lifru
UI Programming/Art by dpfzles

Sounds used under Attribution copyright:

Skulker Alert: https://freesound.org/people/Elpati%C3%B1o/sounds/706482/
Skulker Death: https://freesound.org/people/scorpion67890/sounds/614315/
Predator Alert: https://freesound.org/people/thanvannispen/sounds/94580/
Predator Death: https://freesound.org/people/thanvannispen/sounds/125134/

Part of Attack for Predator/Stalker: https://freesound.org/people/Smullen93/sounds/340341/

Gun animation: https://www.deviantart.com/toomanypenguins/art/Pistol-firing-animation-569253782
